//
//  NSManagedObjectModel+FNCoreData.h
//  FNAppKit
//
//  Created by Alexander Rinaß on 06.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <CoreData/CoreData.h>

/**
 Extensions for the default Core Data stack.
 
 See FNCoreData for more information.
 */
@interface NSManagedObjectModel (FNCoreData)

/** @name Setting and Retrieving the Default Managed Object Model */

/**
 Sets the default Managed Object Model used by the default Core Data stack from the given 
 bundle and model name.
 @param bundle The bundle used to look up the model resource
 @param modelName The name of the Core Data model
 */
+ (void)setDefaultManagedObjectModelFromBundle:(NSBundle *)bundle withName:(NSString *)modelName;

/**
 Sets the default Managed Object Model used by the default Core Data stack.
 @param managedObjectModel A Managed Object Model that should be the default used by the default Core Data stack
 */
+ (void)setDefaultManagedObjectModel:(NSManagedObjectModel *)managedObjectModel;

/**
 Retrieves the current default Managed Object Model used by the default Core Data stack.
 @returns The default Managed Object Model used by the default Core Data stack
 */
+ (NSManagedObjectModel *)defaultManagedObjectModel;

@end
