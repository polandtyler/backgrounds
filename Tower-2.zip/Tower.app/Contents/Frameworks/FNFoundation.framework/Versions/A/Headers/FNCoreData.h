//
//  FNCoreData.h
//  FNAppKit
//
//  Created by Alexander Rinaß on 06.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSManagedObjectModel+FNCoreData.h"
#import "NSPersistentStoreCoordinator+FNCoreData.h"
#import "NSManagedObjectContext+FNCoreData.h"
#import "NSManagedObject+FNCoreData.h"
#import "FNCoreDataObserver.h"

/**
 Helper to set up and configure a CoreData stack.
 
 The usual CoreData stack is made up of the following:
 
 * NSManagedObjectModel
 * NSPersistentStoreCoordinator
 * NSManagedObjectContext that runs a private queue. This is the 'masterContext'
 * NSManagedObjectContext for the main thread. This is a childContext of our 
   masterContext
 * NSManagedObjectContext that runs a private queue. This can be used to
   perform work in background. This context is a child Context of the 
   masterContext
 
 The NSManagedObjectModel is assumed to be named `PRODUCT_NAME.momd` and to 
 reside in the main bundle of the application.
 
 If the data model is named differently or when unit testing, you have to create
 it manually and set it as the default NSManagedObjectModel. 
 
 There is a convenience method to set the default managed from a bundle
 (e.g. for unit testing):
 
    [FNCoreData useManagedObjectModelFromBundle:[NSBundle bundleForClass:[self class]] withName:@"FNCoreDataTests"];
 
 The NSPersistentStoreCoordinator will create a data store file in the 
 Application Support directory for your application with the file name set to
 `PRODUCT_NAME.store`.
 
 When using the NSSQLiteStoreType or NSXMLStoreType for Unit Tests, you need to
 specify the full store URL as FNCoreData will not be able to retrieve a valid
 Application Support Directory or Product Name.
 
 An alternative is to set the default NSPersistentStoreCoordinator by creating 
 one manually and setting it with 
 `[NSPersistentStoreCoordinator setMainPersistentStoreCoordinator:store]`.
 */
@interface FNCoreData : NSObject

/** @name Setting a Custom Main Managed Object Model */

/**
 Sets the default Managed Object Model from the given bundle and data model name.
 
 Use this method if your data model is not in the application's main bundle or is named differently
 than the application name.
 */
+ (void)useManagedObjectModelFromBundle:(NSBundle *)bundle withName:(NSString *)modelName;

/** @name Managing the Default Bundle */

+ (NSBundle *)defaultBundle;
+ (void)setDefaultBundle:(NSBundle *)bundle;

/** @name Getting the Store URL */

+ (NSURL *)storeURL;
+ (void)setStoreURL:(NSURL *)storeURL;

/** @name Setting Up a Core Data Stack */

+ (BOOL)isCoreDataStackSetUp;

+ (NSString *)stackUUID;
+ (void)setStackUUID:(NSString *)stackUUID;

/**
 Sets up a Core Data stack with an In-Memory store.
 */
+ (BOOL)setUpCoreDataStackWithInMemoryStoreType:(NSError * __autoreleasing *)error;

/**
 Sets up a Core Data stack with the given store type and options.
 */
+ (BOOL)setUpCoreDataStackWithStoreType:(NSString *)storeType options:(NSDictionary *)options error:(NSError * __autoreleasing *)error;

/**
 Sets up a Core Data stack with the given store type, store name and options.
 
 This method lets you choose a different store name than the default one.
 */
+ (BOOL)setUpCoreDataStackWithStoreType:(NSString *)storeType storeName:(NSString *)storeName options:(NSDictionary *)options error:(NSError * __autoreleasing *)error;

/**
 Sets up a Core Data stack with the given store type, store URL and options.
 
 This method lets you choose a different store URL than the default one.
 */
+ (BOOL)setUpCoreDataStackWithStoreType:(NSString *)storeType storeURL:(NSURL *)storeURL options:(NSDictionary *)options error:(NSError * __autoreleasing *)error;

/** @name Tearing Down the Core Data Stack */

/**
 Tears down the default Core Data stack set up by one of the methods above.
 */
+ (void)tearDownCoreDataStack;

/** @name Removing the Store */

+ (BOOL)deleteStore:(NSError * __autoreleasing *)error;

@end
