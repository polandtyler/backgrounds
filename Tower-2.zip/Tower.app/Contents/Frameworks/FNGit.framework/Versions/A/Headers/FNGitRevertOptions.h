//
//  FNGitRevertOptions.h
//  FNGit
//
//  Created by Alexander Rinass on 03.09.13.
//  Copyright (c) 2013 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const FNGitRevertOptionMainlineParentNumber;
extern NSString *const FNGitRevertOptionCommitChanges;
extern NSString *const FNGitRevertOptionFastForward;
