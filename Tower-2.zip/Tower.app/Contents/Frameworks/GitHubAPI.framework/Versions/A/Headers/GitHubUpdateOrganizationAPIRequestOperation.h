//
//  GitHubUpdateOrganizationAPIRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 19.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@class GitHubAccount;

typedef void (^GitHubUpdateOrganizationErrorHandler)(NSError *error);
typedef void (^GitHubUpdateOrganizationCompletionHandler)(GitHubAccount *organization);

@interface GitHubUpdateOrganizationAPIRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, strong, readonly) GitHubAccount *organization;
@property (nonatomic, readonly, getter = isUpdated) BOOL updated;
@property (nonatomic, copy) GitHubUpdateOrganizationErrorHandler errorHandler;
@property (nonatomic, copy) GitHubUpdateOrganizationCompletionHandler completionHandler;

#pragma mark - Factory Methods

+ (id)requestWithAuth:(GitHubAuth *)auth organization:(GitHubAccount *)organization;

#pragma mark - Initialization

- (id)initWithAuth:(GitHubAuth *)auth organization:(GitHubAccount *)organization;

#pragma mark - Synchronously Sending the Request

- (GitHubAccount *)send:(NSError * __autoreleasing *)error;

@end
