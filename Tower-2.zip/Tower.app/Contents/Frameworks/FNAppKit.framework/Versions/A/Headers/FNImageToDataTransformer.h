//
//  FNImageToDataTransformer.h
//  FNAppKit
//
//  Created by Florian Bürger on 15/08/2012.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNImageToDataTransformer : NSValueTransformer

@end
