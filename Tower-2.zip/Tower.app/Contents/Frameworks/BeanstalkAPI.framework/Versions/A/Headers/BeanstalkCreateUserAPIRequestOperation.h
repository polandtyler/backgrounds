//
//  BeanstalkCreateUserAPIRequestOperation.h
//  BeanstalkAPI
//
//  Created by Alexander Rinaß on 14.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "BeanstalkAPIRequestOperation.h"

@class BeanstalkUser;

typedef void (^BeanstalkCreateUserErrorHandler)(NSError *error);
typedef void (^BeanstalkCreateUserCompletionHandler)(BeanstalkUser *user);

@interface BeanstalkCreateUserAPIRequestOperation : BeanstalkAPIRequestOperation
@property (nonatomic, strong, readonly) BeanstalkUser *user;
@property (nonatomic, readonly, getter = isCreated) BOOL created;
@property (nonatomic, copy) BeanstalkCreateUserErrorHandler errorHandler;
@property (nonatomic, copy) BeanstalkCreateUserCompletionHandler completionHandler;

#pragma mark - Factory Methods

+ (id)requestWithAuth:(BeanstalkAuth *)auth user:(BeanstalkUser *)user;

#pragma mark - Initialization

- (id)initWithAuth:(BeanstalkAuth *)auth user:(BeanstalkUser *)user;
#pragma mark - Sending the Request

#pragma mark - Sending the Request

- (BeanstalkUser *)send:(NSError * __autoreleasing *)error;

@end
