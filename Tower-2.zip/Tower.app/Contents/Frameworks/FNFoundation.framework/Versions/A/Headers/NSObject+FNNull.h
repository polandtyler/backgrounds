//
//  NSObject+FNNull.h
//  FNFoundation
//
//  Created by Alexander Rinass on 09/07/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (FNNull)

- (BOOL)isNull;

@end
