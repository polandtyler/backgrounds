//
//  FNNetworkReachability.h
//  FNFoundation
//
//  Created by Alexander Rinass on 15/07/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNNetworkReachability : NSObject

+ (BOOL)isHostAvailable:(NSString *)hostname;

@end
