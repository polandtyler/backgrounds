//
//  NSManagedObjectContext+FNCoreData.h
//  FNFoundation
//
//  Created by Alexander Rinaß on 06.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <CoreData/CoreData.h>

/**
 Extensions for the default Core Data stack.
 
 See FNCoreData for more information.
 */
@interface NSManagedObjectContext (FNCoreData)

#if MAC_OS_X_VERSION_MIN_REQUIRED <= MAC_OS_X_VERSION_10_9
@property (nonatomic) NSString *name_;
#else
#warning Property backport for `NSManagedObjectContext` `name` no longer required
#endif

/** @name Retrieving the Managed Object Contexts */

/**
 Returns the master context which is associated with the persistent store.
 */
+ (NSManagedObjectContext *)masterPersistentStoreContext;
+ (NSManagedObjectContext *)rootManagedObjectContext __deprecated;

/**
 Returns the main context that is used on the main queue
 (NSMainQueueConcurrencyType).
 
 Always use `performBlock:` or `performBlockAndWait:` to perform tasks on this 
 context.
 */
+ (NSManagedObjectContext *)mainContext;
+ (NSManagedObjectContext *)mainManagedObjectContext __deprecated;

/**
 Returns the main context or context for background tasks depending on current
 thread.
 */
+ (NSManagedObjectContext *)contextForCurrentThread __deprecated;

/**
 Returns a new child context of the main context for use in background tasks.
 
 Always use `performBlock:` or `performBlockAndWait:` to perform tasks on this
 context.
 */
+ (NSManagedObjectContext *)newBackgroundContext;
+ (NSManagedObjectContext *)newBackgroundManagedObjectContext __deprecated;
+ (NSManagedObjectContext *)backgroundManagedObjectContext __deprecated;

/** @name Resetting All Contexts */

+ (void)resetAllContexts;

/** @name Retrieving Child Contexts */

/*
 Creates new context with the default type `NSPrivateQueueConcurrencyType`
 and sets the receiver as parent context.
 */
- (NSManagedObjectContext *)childContext;

/*
 Creates new context with the given type and sets the receiver as parent
 context.
 */
- (NSManagedObjectContext *)childContextWithType:(NSManagedObjectContextConcurrencyType)type;

/** @name Saving Contexts Recursively */

/**
 Recursively saves contexts in the background.
 */
- (void)saveRecursiveInBackgroundWithCompletionHandler:(void (^)(BOOL success, NSError *error))completionHandler;
- (void)fn_saveToRootInBackground __deprecated;

/**
 Recursively saves contexts and waits.
 */
- (BOOL)saveRecursive:(NSError *__autoreleasing *)error;
- (BOOL)fn_saveToRoot:(NSError *__autoreleasing *)error __deprecated;

@end
