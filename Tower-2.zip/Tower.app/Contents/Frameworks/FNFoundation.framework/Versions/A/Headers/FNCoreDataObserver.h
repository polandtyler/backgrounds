//
//  FNCoreDataObserver.h
//  FNFoundation
//
//  Created by Alexander Rinass on 20/03/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNCoreDataObserver : NSObject

+ (instancetype)sharedObserver;
+ (void)setSharedObserver:(FNCoreDataObserver *)observer;

- (NSArray *)registeredManagedObjectContexts;
- (NSUInteger)registeredManagedObjectContextCount;

- (void)registerManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
- (void)unregisterManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
- (void)unregisterAllManagedObjectContexts;

@end
