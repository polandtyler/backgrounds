//
//  NSString+FNGit.h
//  FNGit
//
//  Created by Alexander Rinass on 19.07.11.
//  Copyright 2011 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (FNGit)

- (NSString *)unquotedCString;

@end
