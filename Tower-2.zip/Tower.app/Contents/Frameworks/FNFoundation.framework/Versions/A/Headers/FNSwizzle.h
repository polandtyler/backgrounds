//
//  FNSwizzle.h
//  FNFoundation
//
//  Created by Florian Bürger on 6/26/12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

void FNSwizzleMethod(Class c, SEL origSEL, SEL overrideSEL);
