//
//  NSPersistentStoreCoordinator+FNCoreData.h
//  FNFoundation
//
//  Created by Alexander Rinaß on 06.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <CoreData/CoreData.h>

/**
 Extensions for the default Core Data stack.
 
 See FNCoreData for more information.
 */
@interface NSPersistentStoreCoordinator (FNCoreData)

/** @name Setting and Retrieving the Default Persistent Store Coordinator */

/**
 Sets the default Persistent Store Coordinator used by the default Core Data stack.
 @param coordinator A Persistent Store Coordinator that should be the default used by the default Core Data stack
 */
+ (void)setDefaultPersistentStoreCoordinator:(NSPersistentStoreCoordinator *)coordinator;

/**
 Retrieves the current default Persistent Store Coordinator used by the default Core Data stack.
 @returns The default Persistent Store Coordinator used by the default Core Data stack
 */
+ (NSPersistentStoreCoordinator *)defaultPersistentStoreCoordinator;

+ (NSPersistentStoreCoordinator *)persistentStoreCoordinatorWithManagedObjectModel:(NSManagedObjectModel *)createManagedObjectModel storeType:(NSString *)storeType storeURL:(NSURL *)storeURL options:(NSDictionary *)options error:(NSError * __autoreleasing *)error;

@end
