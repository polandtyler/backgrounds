//
//  NSManagedObject+FNCoreData.h
//  FNFoundation
//
//  Created by Alexander Rinaß on 22.02.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObject (FNCoreData)

/** @name Retrieving Entity Information */

+ (NSString *)entityName;
+ (NSEntityDescription *)entity;
+ (NSEntityDescription *)entityInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

/** @name Creating New Managed Objects */

+ (instancetype)managedObjectWithObjectID:(NSManagedObjectID *)objectID;
+ (instancetype)managedObjectWithObjectID:(NSManagedObjectID *)objectID inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

- (instancetype)initWithManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

// NEW

/**
 Convenience method to create an empty managed object in the main context.
 */
+ (instancetype)create;
+ (instancetype)createWithAttributes:(NSDictionary *)attributes;

/**
 Convenience method to create an empty managed object in the given context.
 */
+ (instancetype)createInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

/**
 Convenience method to create a managed object in the given context with the given attributes.
 */
+ (instancetype)createInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext attributes:(NSDictionary *)attributes;

/**
 Convenience method to create an empty managed object without context.
 */
+ (instancetype)createInMemory;

/**
 Convenience method to create a managed object without context with the given attributes.
 */
+ (instancetype)createInMemoryWithAttributes:(NSDictionary *)attributes;

// OLD

+ (instancetype)managedObjectWithoutManagedObjectContext __deprecated;
+ (instancetype)newManagedObject __deprecated;
+ (instancetype)newManagedObjectInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext __deprecated;

/** @name Counting ManagedObjects */

+ (NSUInteger)countAll:(NSError * __autoreleasing *)error;
+ (NSUInteger)countAllInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext error:(NSError * __autoreleasing *)error;

+ (NSUInteger)countAllWithPredicate:(NSPredicate *)predicate error:(NSError * __autoreleasing *)error;
+ (NSUInteger)countAllWithPredicate:(NSPredicate *)predicate managedObjectContext:(NSManagedObjectContext *)managedObjectContext error:(NSError * __autoreleasing *)error;

/** @name Fetching ManagedObjects */

+ (NSArray *)fetchAll:(NSError * __autoreleasing *)error;
+ (NSArray *)fetchAllInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext error:(NSError * __autoreleasing *)error;

+ (NSArray *)fetchAllWithSortDescriptors:(NSArray *)sortDescriptors error:(NSError * __autoreleasing *)error;
+ (NSArray *)fetchAllWithSortDescriptors:(NSArray *)sortDescriptors inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext error:(NSError * __autoreleasing *)error;

+ (NSArray *)fetchAllWithPredicate:(NSPredicate *)predicate sortDescriptors:(NSArray *)sortDescriptors error:(NSError * __autoreleasing *)error;
+ (NSArray *)fetchAllWithPredicate:(NSPredicate *)predicate sortDescriptors:(NSArray *)sortDescriptors inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext error:(NSError * __autoreleasing *)error;
+ (NSArray *)fetchAllWithPredicate:(NSPredicate *)predicate sortDescriptors:(NSArray *)sortDescriptors limit:(NSUInteger)limit inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext error:(NSError * __autoreleasing *)error;


+ (instancetype)fetchFirstWithPredicate:(NSPredicate *)predicate error:(NSError * __autoreleasing *)error;
+ (instancetype)fetchFirstWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)context error:(__autoreleasing NSError **)error;

+ (instancetype)fetchFirstByAttribute:(NSString *)attribute withValue:(id)value error:(NSError * __autoreleasing *)error;
+ (instancetype)fetchFirstByAttribute:(NSString *)attribute withValue:(id)value inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext error:(NSError * __autoreleasing *)error;

/** @name Refreshing ManagedObjects */

- (void)refreshMergingChanges:(BOOL)mergeChanges;

/** @name Obtaining Permanent Object ID */

- (BOOL)obtainPermanentID:(NSError * __autoreleasing *)error;

/** @name Deleting ManagedObjects */

- (void)destroy;
- (BOOL)isDestroyed;

/** @name Saving ManagedObjects */

- (BOOL)save:(NSError * __autoreleasing *)error;
- (BOOL)saveRecursive:(NSError * __autoreleasing *)error;
- (void)saveRecursiveInBackgroundWithCompletionHandler:(void (^)(BOOL success, NSError *error))completionHandler;

@end
