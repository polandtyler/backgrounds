//
//  FNGitRefLog.h
//  FNGit
//
//  Created by Alexander Rinass on 01.06.11.
//  Copyright 2011 Fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface FNGitRefLog : NSObject {

}

@end
