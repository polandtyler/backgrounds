//
//  NSArray+FNTransforming.h
//  FNFoundation
//
//  Created by Alexander Rinass on 25/08/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (FNTransforming)

- (NSArray *)reversedArray;

@end
