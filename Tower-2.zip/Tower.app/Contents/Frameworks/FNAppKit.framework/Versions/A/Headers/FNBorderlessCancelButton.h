//
//  FNBorderlessCancelButton.h
//  Tower
//
//  Created by Alexander Rinass on 05.07.12.
//  Copyright (c) 2012 fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FNBorderlessCancelButton : NSButton

@end
