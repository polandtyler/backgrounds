//
//  FNGitSVNShowIgnoreCommand.h
//  FNGit
//
//  Created by Alexander Rinass on 06.08.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <FNGit/FNGit.h>

@interface FNGitSVNShowIgnoreCommand : FNGitCommand

@end
